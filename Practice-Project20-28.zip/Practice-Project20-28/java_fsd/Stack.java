package com.shaelm.java_fsd;
public class Stack 
{
	private int x[];
	private int top;
	private int capacity;
	
	Stack(int size)
	{
		x = new int[size];
		capacity = size;
		top = -1;
	}
	
	public boolean isEmpty()
	{
		return top == -1;
	}
	
	public boolean isFull()
	{
		return top == capacity-1;
	}
	
	public void Push(int n)
	{
		if(this.isFull())
		{
			System.out.println("\nStack OverFlow");
			System.exit(0);
		}
		x[++top] = n; // 
		System.out.println("Inserted Value : " + n);
	}
	
	public int Pop()
	{
		if(this.isEmpty())
		{
			System.out.println("\nStack is Empty");
			System.exit(0);
		}
		
		return x[top--];
	}
	
	public void printStack()
	{
		System.out.println();
		for(int i=0;i<=top;i++)
		{
			System.out.print(x[i] + "\t");
		}
	}
	
	public static void main(String[] args)
	{
		Stack  stk = new Stack(5);
		
		stk.Push(10);
		stk.Push(20);
		stk.Push(30);
		stk.Push(40);
		stk.Push(50);
		stk.printStack();
		
		System.out.println("Removed Value is : " + stk.Pop());
		stk.printStack();
		System.out.println("Removed Value is : " + stk.Pop());
		stk.printStack();
		System.out.println("Removed Value is : " + stk.Pop());
		stk.printStack();
		System.out.println("Removed Value is : " + stk.Pop());
		stk.printStack();
		System.out.println("Removed Value is : " + stk.Pop());
		stk.printStack();
		System.out.println("Removed Value is : " + stk.Pop());
	}
}
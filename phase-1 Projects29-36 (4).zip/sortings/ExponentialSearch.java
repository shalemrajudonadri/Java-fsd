package com.works.sortings;

import java.util.Arrays;
import java.util.Scanner;

public class ExponentialSearch {

	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		
		int arr[]= {64,112,108,724,342};
	    int length= arr.length;
	    System.out.println("Enter the value to search");
	     int value=Sc.nextInt();
	     
	    
	   
	    int outcome = exponentialSearch(arr,length,value);
	    if(outcome<0){

	        System.out.println( "Element is not present in the array");

	     }else {

	         System.out.println( "Element is  present in the array at index :"+outcome);
	     }

	         }

	         public static int exponentialSearch(int[] arr ,int length, int value ){
	         if(arr[0]==value){
	             return 0;
	             }
	         int i=1;
	         while(i<length && arr[i]<=value){

	             i=i*2;
	         }
	         return Arrays.binarySearch(arr,i/2,Math.min(i,length),value);
	         }
}
package com.shaelm.java_fsd;

import java.util.Scanner;

public class RightRotateArray {
	
	void rightRotate(int arr[], int d, int n)
	{
		while (d > n) {
			d = d - n;
		}		
		int temp[] = new int[n - d];
		for (int i = 0; i < n - d; i++)
			temp[i] = arr[i];
		for (int i = n - d; i < n; i++) {
			arr[i - n + d] = arr[i];
		}
		for (int i = 0; i < n - d; i++) {
			arr[i + d] = temp[i];
		}
	}
	void printArray(int arr[], int n)
	{
		for (int i = 0; i < n; i++)
			System.out.print(arr[i] + " ");
	}
	public static void main(String[] args)
	{
		RightRotateArray rotate = new RightRotateArray();
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array: ");
        int arr_size = 0;
        if (sc.hasNextInt()) {
            arr_size = sc.nextInt();
        }
        int[] arr = new int[arr_size];
        System.out.println(
            "Enter the elements of the array: ");         
        for (int i = 0; i < arr_size; i++) {
            if (sc.hasNextInt()) {
                arr[i] = sc.nextInt();
            }
        }           
        System.out.println(
            "The elements of the array are: ");
        for (int i = 0; i < arr_size; i++) {       	 
            System.out.print(arr[i] + " ");
        }
        System.out.println(" ");
        sc.close();
		rotate.rightRotate(arr, 5, arr.length);
		rotate.printArray(arr, arr.length);
	}
}




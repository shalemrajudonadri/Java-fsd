package com.shalemworks.oops;

public class College extends Inheritance{
	

	  public void getInfo() {
	    System.out.println("My name is " + name);
	  }

	}